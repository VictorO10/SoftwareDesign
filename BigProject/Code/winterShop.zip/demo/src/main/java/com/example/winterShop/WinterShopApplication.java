package com.example.winterShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WinterShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(WinterShopApplication.class, args);
	}
}
